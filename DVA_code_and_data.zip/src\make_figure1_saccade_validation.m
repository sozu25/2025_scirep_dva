function make_figure1_saccade_validation(subj, wfMat)
% MAKE_FIGURE1_SACCADE_VALIDATION  論文 図1: サッケード（速度閾値事象）の妥当性検証（ポジティブコントロール）。
%
%   出力: figures/figure1_saccade_validation_<subj>.png
%
%   レイアウト (2行×5列):
%     行1 = Vertical, 行2 = Horizontal
%       列1: 代表被験者1名の 標的(optotype)位置 と 眼球位置
%       列2: 同 速度（サッケード性 excursion を赤で表示。±VT の閾値線を併記）
%       列3: 全16名の main sequence（振幅 vs ピーク速度; 飽和則）
%       列4: 全16名の main sequence（振幅 vs 持続時間; 線形則）
%     列5 (2行ぶち抜き): 被験者×方向ごとの main sequence R^2 を群別に表示
%
%   事象定義: 検出器（ピーク検出・prominence・GMM）を使わず、**眼球速度 |v| >= VT (=75 deg/s,
%   ヒトの平滑追従の速度上限, ref 22 準拠) の連続区間**を1事象とする（src/threshold_events.m）。
%   これは振幅分解（make_tableS1）が使う per-sample 閾値と同一基準で、検証と定量が単一閾値に一本化される。
%
%   狙い: この閾値事象が「本物のサッケード」であることを、眼球運動研究の標準則
%   （main sequence の 2 本柱: 振幅→ピーク速度が飽和、振幅→持続時間が線形）で実証する。
%   さらに R^2 が群間で差がないことを示し、検出品質の偏りが群比較を交絡しないことを担保する。
%
%   figures/figure1_saccade_validation_<subj>.png に保存。
    thisDir=fileparts(mfilename('fullpath')); repoRoot=fileparts(thisDir);
    if nargin<2||isempty(wfMat); wfMat=fullfile(repoRoot,'data','processed','rotation_waveforms_hbw.mat'); end
    WF=load_waveforms(wfMat); FS=500; VT=75;   % 速度は 8ms 群遅延を補正済み。VT=75 = 原著引用文献22 (Palidis 2017) 準拠
    G=readtable(fullfile(repoRoot,'config','subject_group.csv'),'TextType','string');
    % 代表被験者。省略時は config/figure1_example_subject.txt から読む。
    % 実名をコードに埋めないことで、匿名化した寄託版でも**論文と同じ被験者**が選ばれる
    % （寄託版ではこのファイルに匿名名が入る。build_deposit.m 参照）。
    if nargin<1||isempty(subj)
        f=fullfile(repoRoot,'config','figure1_example_subject.txt');
        if isfile(f); subj=strtrim(string(fileread(f))); else; subj=G.name(1); end
    end
    subj=string(subj);
    key=string({WF.key}'); P=split(key,'|'); nm=P(:,1); dr=P(:,4);
    colC=[0 0.4470 0.7410]; colS=[0.8500 0.3250 0.0980];

    % ---- 全事象を集める（窓に切られた事象は振幅が過小のため運動学評価から除外）----
    %   除外は「端から MARGIN 以上内側」で行う（速度の 8ms 遅延補正で区間が内側にずれるため、
    %   窓端に接する事象を素朴に判定すると取りこぼす）。
    %   実測（VT=75, 60Hz, MARGIN=8）: n=4028, 飽和則 R^2=0.856, 線形則 2.33·A+12 r=0.91。
    MARGIN=8;
    amp=[];pv=[];dur=[];sub=strings(0,1);dirs=strings(0,1);
    for i=1:numel(WF)
        S=threshold_events(WF(i).pos,WF(i).vel,FS,VT);
        k = S.a>MARGIN & S.b<numel(WF(i).pos)-MARGIN;
        amp=[amp;S.amp(k)]; pv=[pv;S.pv(k)]; dur=[dur;S.dur(k)]; %#ok<AGROW>
        sub=[sub;repmat(nm(i),sum(k),1)]; dirs=[dirs;repmat(dr(i),sum(k),1)]; %#ok<AGROW>
    end
    [~,gl]=ismember(sub,G.name); grpOf=G.group(gl);

    fig=figure('Visible','on','Position',[30 30 1900 820]);
    % ---- Affinity 手編集を減らすための体裁既定（フォント/サイズはここ1箇所で調整）----
    FONT='Times New Roman'; FSax=13; FSlab=14; FSlg=12;
    set(fig,'DefaultAxesFontName',FONT,'DefaultAxesFontSize',FSax, ...
            'DefaultTextFontName',FONT,'DefaultLegendFontSize',FSlg);
    tl=tiledlayout(fig,2,3,'TileSpacing','compact','Padding','compact');
    dirsL=["V","H"]; dirName=["Vertical","Horizontal"];
    tileRow={[1 2 3],[4 5 6]};
    for di=1:2
        tr=tileRow{di}; d=dirsL(di);
        % ===== 列1,2: 代表被験者の1試行 =====
        sel=find(nm==subj & dr==d);
        tk=key(sel); tu=unique(tk); tot=zeros(numel(tu),1);
        for j=1:numel(tu); tot(j)=sum(arrayfun(@(i) numel(WF(i).pos), sel(tk==tu(j)))); end
        [~,bi]=max(tot); pick=sel(tk==tu(bi));
        T=[];Pp=[];Vv=[];Tg=[];TgV=[]; off=0;
        for i=pick'
            t=WF(i).tt(:); p=WF(i).pos(:); v=WF(i).vel(:); g=WF(i).tgt(:);
            gv=(g(end)-g(1))/max(t(end)-t(1),eps);
            T=[T;(0:numel(p)-1)'/FS+off; NaN]; Pp=[Pp;p;NaN]; Vv=[Vv;v;NaN]; %#ok<AGROW>
            Tg=[Tg;g;NaN]; TgV=[TgV;repmat(gv,numel(t),1);NaN]; %#ok<AGROW>
            off=off+numel(p)/FS+0.03;
        end
        nexttile(tr(1)); hold on;
        plot(T,Tg,'-','Color',[.6 .6 .6],'LineWidth',1,'DisplayName','Optotype position');
        plot(T,Pp,'-','Color',colC,'LineWidth',0.8,'DisplayName','Eye position');
        hold off; grid on; ylabel('Position [deg]','FontSize',FSlab); xlabel('Time [s]','FontSize',FSlab);
        if di==1; legend('Orientation','horizontal','Location','northoutside','Box','off','FontSize',FSlg); end

        nexttile(tr(2)); hold on;
        plot(T,TgV,'-','Color',[.6 .6 .6],'LineWidth',1,'DisplayName','Optotype velocity');
        plot(T,Vv,'-','Color',colC,'LineWidth',0.8,'DisplayName','Eye velocity');
        yline( VT,':','Color',[.4 .4 .4],'LineWidth',0.6,'HandleVisibility','off');
        yline(-VT,':','Color',[.4 .4 .4],'LineWidth',0.6,'HandleVisibility','off');
        off=0; Vs=nan(size(Vv));
        for i=pick'
            S=threshold_events(WF(i).pos,WF(i).vel,FS,VT);
            for k=1:numel(S.a); r=off+(S.a(k):S.b(k)); Vs(r)=Vv(r); end
            off=off+numel(WF(i).pos)+1;
        end
        plot(T,Vs,'r-','LineWidth',1.1,'DisplayName',sprintf('Saccade (>%d deg/s)',VT));
        hold off; grid on; ylabel('Velocity [deg/s]','FontSize',FSlab); xlabel('Time [s]','FontSize',FSlab);
        if di==1; legend('Orientation','horizontal','Location','northoutside','Box','off','FontSize',FSlg); end

        % ===== 列3: 振幅 vs ピーク速度（飽和則）=====
        kd = dirs==d; A=amp(kd); V=pv(kd); Gk=grpOf(kd);
        nexttile(tr(3)); hold on;
        scatter(A(Gk=="control"),V(Gk=="control"),5,colC,'filled','MarkerFaceAlpha',0.12,'HandleVisibility','off');
        scatter(A(Gk=="strobe"), V(Gk=="strobe"), 5,colS,'filled','MarkerFaceAlpha',0.12,'HandleVisibility','off');
        hStr=scatter(nan,nan,42,colS,'filled','DisplayName','Strobe group');   % 凡例用の不透明ダミー
        hCon=scatter(nan,nan,42,colC,'filled','DisplayName','Control group');
        m=@(q,x)q(1)*(1-exp(-x/max(q(2),0.1))); sse=@(q)sum((V-m(q,A)).^2);
        q=fminsearch(sse,[800 14]); xg=linspace(0,max(A),200)';
        plot(xg,m(q,xg),'k-','LineWidth',1,'HandleVisibility','off');
        R2=1-sse(q)/sum((V-mean(V)).^2);
        hold off; grid on; xlim([0 40]); xticks([0 20 40]);
        xlabel('Amplitude [deg]','FontSize',FSlab); ylabel('peak velocity [deg/s]','FontSize',FSlab);
        title(sprintf('{\\itR}^2 = %.2f ({\\itn} = %d)', R2, numel(A)),'FontWeight','normal','FontSize',FSax);
        % 凡例（群）は列3の上部・上段のみ。凡例マーカは散布点より大きく見せる
        if di==1
            lg=legend([hStr hCon],'Orientation','horizontal','Location','northoutside','Box','off','FontSize',FSlg);
            lg.ItemTokenSize=[12 12];
        end

        % % ===== 列4: 振幅 vs 持続時間（線形則）=====
        % Dd=dur(kd);
        % nexttile(tr(4)); hold on;
        % scatter(A(Gk=="control"),Dd(Gk=="control"),5,colC,'filled','MarkerFaceAlpha',0.3);
        % scatter(A(Gk=="strobe"), Dd(Gk=="strobe"), 5,colS,'filled','MarkerFaceAlpha',0.3);
        % pl=polyfit(A,Dd,1); plot(xg,polyval(pl,xg),'k-','LineWidth',2.2);
        % % 線形フィットでは R^2=r^2 なので、相関の強さは r で報告する（r=0.77 を R^2=0.59 と
        % % 書くと不当に弱く見える）。傾きが古典(Carpenter: 2.2*A+21)より浅いのは 60Hz 帯域に
        % % よる圧縮と、これが step 課題でなく高速追従中の catch-up サッケードであるため。
        % rd=corr(A,Dd);
        % hold off; grid on; xlim([0 40]); xlabel('amplitude [deg]'); ylabel('duration [ms]');
        % title(sprintf('main sequence: linear (%.2f\\cdotA+%.0f, r=%.2f)',pl(1),pl(2),rd),'FontSize',9);
    end

    % ---- 左端に行ラベル（回転）: Vertical / Horizontal direction ----
    axL=axes(fig,'Position',[0 0 1 1],'Visible','off'); xlim(axL,[0 1]); ylim(axL,[0 1]);
    text(axL,0.010,0.66,'Vertical direction','Rotation',90,'FontName',FONT,'FontSize',FSlab, ...
        'HorizontalAlignment','center','VerticalAlignment','middle');
    text(axL,0.010,0.26,'Horizontal direction','Rotation',90,'FontName',FONT,'FontSize',FSlab, ...
        'HorizontalAlignment','center','VerticalAlignment','middle');
    uistack(axL,'bottom');

    % % ===== 列5 (2行ぶち抜き): 共通 main sequence からの相対残差を群別に =====
    % %   R^2 は振幅範囲に強く依存する（狭い範囲では曲率も分散も乏しく必ず低く出る:
    % %   実測 corr(ampSD,R^2)=+0.59。例 Subject C IQR 3deg→R^2=0.60 vs Subject J H IQR 22deg→R^2=0.94）。
    % %   そこで「その被験者のサッケードが**共通の**主系列にどれだけ乗るか」を、範囲に依存しない
    % %   相対残差 median(|pv - pred|/pred) で評価する（実測 corr(ampSD,相対残差)=-0.21＝ほぼ非依存）。
    % mAll=@(q,x)q(1)*(1-exp(-x/max(q(2),0.1)));
    % sseAll=@(q)sum((pv-mAll(q,amp)).^2); qAll=fminsearch(sseAll,[800 14]);   % 共通(プール)主系列
    % subs=G.name; rel=[]; gg=strings(0,1); dd2=strings(0,1);
    % for s=1:numel(subs)
    %     for d=dirsL
    %         k=sub==subs(s)&dirs==d; if nnz(k)<20; continue; end
    %         pred=mAll(qAll,amp(k));
    %         rel(end+1,1)=median(abs(pv(k)-pred)./pred); %#ok<AGROW>
    %         gg(end+1,1)=G.group(G.name==subs(s)); dd2(end+1,1)=d; %#ok<AGROW>
    %     end
    % end
    % nexttile(5,[2 1]); hold on;
    % g=["control","strobe"]; c={colC,colS};
    % for gi=1:2
    %     y=rel(gg==g(gi)); x=gi+0.12*randn(size(y)); sV=dd2(gg==g(gi))=="V";
    %     scatter(x(sV),y(sV),40,c{gi},'filled','MarkerFaceAlpha',0.75,'Marker','o');
    %     scatter(x(~sV),y(~sV),40,c{gi},'MarkerEdgeColor',c{gi},'LineWidth',1.2,'Marker','s');
    %     plot([gi-0.28 gi+0.28],[median(y) median(y)],'k-','LineWidth',2);
    % end
    % [~,pg]=ttest2(rel(gg=="control"),rel(gg=="strobe"));
    % hold off; grid on; xlim([0.5 2.5]); xticks([1 2]); xticklabels({'control','strobe'});
    % ylabel('relative deviation from the common main sequence');
    % title(sprintf('how well each subject follows\nthe COMMON main sequence\nmedian=%.0f%% [%.0f-%.0f%%], group p=%.2f (n.s.)', ...
    %     100*median(rel),100*min(rel),100*max(rel),pg),'FontSize',9);
    % ylim([0 max(rel)*1.25]);
    % text(0.6, max(rel)*1.15, 'filled = Vertical,  open = Horizontal', 'FontSize',7,'Color',[.3 .3 .3]);
    % 
    % title(tl,sprintf(['Figure 1 — Saccade validation (positive control): events = |v| \\geq %d deg/s excursions. ' ...
    %     'Example subject: %s. 60 Hz low-pass.'],VT,subj), ...
    %     'Interpreter','tex');
    % % ファイル名では空白を _ に（匿名版の "Subject O" がファイル名に空白を持ち込むため）。
    % % 図中の表示名は subj のまま。
    % 出力（原稿 図5 の素材パネル）。ファイル名では空白を _ に置換する
    % （匿名版の "Subject O" がファイル名に空白を持ち込むため）。図中の表示名は subj のまま。
    outDir=fullfile(repoRoot,'figures');
    if ~exist(outDir,'dir'); mkdir(outDir); end
    png=fullfile(outDir, sprintf('figure1_saccade_validation_%s.png', regexprep(subj,'\s+','_')));
    exportgraphics(fig,png,'Resolution',150);
    fprintf('saved %s\n',png);
    % fprintf('relative deviation from common main sequence: median=%.1f%% range=[%.1f-%.1f%%], group diff p=%.3f\n', ...
    %     100*median(rel),100*min(rel),100*max(rel),pg);
end
