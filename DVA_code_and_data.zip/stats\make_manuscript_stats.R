## make_manuscript_stats.R
## 原稿の統計（Table 1-3, MAE 表, および Figure 4 の有意差マーク）を一括で再現する。
##
##   実行:  Rscript stats/make_manuscript_stats.R
##   出力:  tables/table1_dva.csv, tables/table2_saccadic_contribution.csv,
##          tables/table3_displacement_components.csv, tables/table_mae.csv,
##          tables/figure4_pairwise.csv
##
## モデル・コーディングは原稿の表注記に合わせる:
##   y ~ D*G*T + (1|participant),  REML
##   D = ±0.5 (vertical / horizontal), G = ±0.5 (strobe / control),
##   T = セッション番号を平均で中心化（係数はセッションあたりの傾き）
##   自由度は Satterthwaite 近似 (lmerTest)。
##
## 群分けは config/subject_group.csv を単一の情報源とする。データ側の glass 列とは
## 独立に config を参照するので、両者が食い違えば下の検査で停止する。

suppressPackageStartupMessages({
  need <- c("lme4", "lmerTest", "emmeans")
  miss <- need[!sapply(need, requireNamespace, quietly = TRUE)]
  if (length(miss)) stop("必要なパッケージが未導入です: ", paste(miss, collapse = ", "))
  library(lme4); library(lmerTest); library(emmeans)
})

## スクリプト自身の位置からリポジトリルートを解決する（寄託版でもそのまま動く）
args    <- commandArgs(trailingOnly = FALSE)
fileArg <- sub("^--file=", "", args[grep("^--file=", args)])
ROOT    <- if (length(fileArg)) normalizePath(file.path(dirname(fileArg), "..")) else normalizePath("..")
DATA   <- file.path(ROOT, "data", "processed")
TABLES <- file.path(ROOT, "tables")
dir.create(TABLES, showWarnings = FALSE, recursive = TRUE)

## glass 列は "T"/"F"。read.csv の論理値変換を止めるため character で読む。
rd <- function(f) read.csv(file.path(DATA, f), colClasses = c(glass = "character"))

G <- read.csv(file.path(ROOT, "config", "subject_group.csv"), colClasses = c(glass = "character"))
strobe <- G$name[G$glass == "T"]
cat(sprintf("群分け (config/subject_group.csv): strobe %d 名 / control %d 名\n",
            length(strobe), sum(G$glass == "F")))

prep <- function(d) {
  stopifnot(all(d$name %in% G$name))
  ## データ側の glass 列と config の整合を確認する
  own <- sort(unique(d$name[d$glass == "T"]))
  if (!identical(own, sort(strobe)))
    stop("データの glass 列が config/subject_group.csv と一致しません: ",
         paste(setdiff(union(own, strobe), intersect(own, strobe)), collapse = ", "))
  d$Dn <- ifelse(d$direction == "V", 0.5, -0.5)
  d$Gn <- ifelse(d$name %in% strobe, 0.5, -0.5)
  d$Tc <- d$days - mean(sort(unique(d$days)))
  d
}

lmm <- function(d, yname) {
  d$y <- d[[yname]]
  m   <- lmer(y ~ Dn * Gn * Tc + (1 | name), data = d, REML = TRUE)
  cf  <- summary(m)$coefficients
  lab <- c("(Intercept)" = "Intercept", "Dn" = "Vertical direction (D)",
           "Gn" = "Strobe group (G)", "Tc" = "Training sessions (T)",
           "Dn:Gn" = "D x G", "Dn:Tc" = "D x T", "Gn:Tc" = "T x G",
           "Dn:Gn:Tc" = "D x T x G")
  data.frame(effect   = unname(lab[rownames(cf)]),
             estimate = round(cf[, "Estimate"], 3),
             std_error = round(cf[, "Std. Error"], 3),
             df       = round(cf[, "df"], 1),
             t_value  = round(cf[, "t value"], 2),
             p_value  = signif(cf[, "Pr(>|t|)"], 3),
             row.names = NULL)
}

wr <- function(x, f) {
  write.csv(x, file.path(TABLES, f), row.names = FALSE)
  cat(sprintf("\n---- %s ----\n", f)); print(x, row.names = FALSE)
}

## ---- Table 1: DVA ---------------------------------------------------------
DVA <- prep(rd("dva_pertrial.csv"))
wr(lmm(DVA, "DVA"), "table1_dva.csv")

## ---- Figure 4 パネル C/D の有意差マーク（V vs H, Holm 8 件）----------------
DVA$Df <- factor(DVA$direction, levels = c("H", "V"))
DVA$Gf <- factor(ifelse(DVA$Gn > 0, "strobe", "control"), levels = c("control", "strobe"))
m4  <- lmer(DVA ~ Df * Gf * Tc + (1 | name), data = DVA, REML = TRUE)
emm <- emmeans(m4, ~ Df | Gf * Tc,
               at = list(Tc = sort(unique(DVA$Tc))), lmer.df = "satterthwaite")
pr  <- as.data.frame(pairs(emm, adjust = "none"))
pr$group   <- as.character(pr$Gf)
pr$session <- round(pr$Tc + mean(sort(unique(DVA$days))))
pr$p_holm  <- p.adjust(pr$p.value, method = "holm")
pr$star    <- cut(pr$p_holm, c(-Inf, .001, .01, .05, Inf), labels = c("***", "**", "*", "n.s."))
wr(pr[order(pr$group, pr$session), c("group","session","estimate","SE","df","t.ratio","p.value","p_holm","star")],
   "figure4_pairwise.csv")

## ---- Table 2: サッカード寄与率（総和比）------------------------------------
P <- prep(rd("pathlen_pertrial.csv"))
frac <- function(s) round(100 * sum(s$saccadic) / sum(s$A), 1)
T2 <- do.call(rbind, lapply(c("control", "strobe"), function(g) {
  s <- P[ifelse(P$Gn > 0, "strobe", "control") == g, ]
  data.frame(group = g, overall = frac(s),
             vertical = frac(s[s$direction == "V", ]),
             horizontal = frac(s[s$direction == "H", ]))
}))
wr(T2, "table2_saccadic_contribution.csv")

## ---- Table 3: 変位成分 -----------------------------------------------------
T3 <- rbind(cbind(component = "A_s",  lmm(P, "saccadic")),
            cbind(component = "A_ns", lmm(P, "non_saccadic")))
wr(T3, "table3_displacement_components.csv")

## ---- MAE 表 ----------------------------------------------------------------
E <- prep(rd("position_error_pertrial.csv"))
wr(lmm(E, "maperr"), "table_mae.csv")

cat("\n完了。tables/ に 5 つの CSV を出力しました。\n")
