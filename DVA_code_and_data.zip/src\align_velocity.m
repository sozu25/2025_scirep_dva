function v = align_velocity(v, delay)
% ALIGN_VELOCITY  diff_filter の群遅延を補正し、速度を位置と同じ時刻に揃える。
%
%   v = ALIGN_VELOCITY(v)        既定 delay=4 サンプル (8 ms @500Hz) で補正
%   v = ALIGN_VELOCITY(v, delay) 補正量を明示（delay=0 で無補正＝旧挙動）
%
%   ── なぜ必要か ────────────────────────────────────────────────────
%   diff_filter は
%       y(i) = ( x(i)+x(i-1)+x(i-2) - x(i-6)-x(i-7)-x(i-8) ) / 18 * fs
%   すなわち「前3点平均と後3点平均の差」である。正側タップの重心は lag 1、
%   負側は lag 7 なので、この推定は**中点 lag 4 の時刻の微分**を表す。つまり
%   出力は位置に対して 4 サンプル = 8 ms 遅れる（線形位相）。legacy パイプライン
%   (Test_*.m → replicate_amp) は先頭 8 点を捨てるだけでこの遅延を補正していない。
%
%   実測でも保存波形の pos と vel は +3〜4 サンプルずれている（中心差分との
%   相互相関ラグ +3、r=0.853）。サッケードの持続時間は中央値 36 ms なので、
%   8 ms は事象長の 2 割強にあたる。detect_saccades_ms は速度側で区間 [a,b] を
%   決めて |pos(b)-pos(a)| で振幅を測るため、補正しないと**区間が実際の
%   サッケードより 8 ms 遅くずれ、振幅が汚れる**。
%
%   補正の効果（窓端に接する事象を除いた公平比較, 60Hz LPF）:
%       無補正: 飽和則 R^2=0.834, 線形則 r=0.758 (傾き 1.43)
%       補正済: 飽和則 R^2=0.862, 線形則 r=0.789 (傾き 1.60)  ← 古典値 2.2 に接近
%
%   ── 既報 amp への影響はない ───────────────────────────────────────
%   既報の振幅 A は位置の peak-to-peak のみで速度を使わないため、この補正は
%   A を一切変えない。よって replicate_amp（公開 data_EYE.csv と全4848行が
%   厳密一致する検証済みコード）は変更せず、速度を使う解析側で補正する。
%
%   末尾 delay サンプルは最終値で埋める（位置を切り詰めると窓が変わり A が
%   変わってしまうため、位置は一切触らない）。窓端の事象は S.edge で識別できる。
    if nargin < 2 || isempty(delay); delay = 4; end
    v = v(:);
    if delay == 0 || isempty(v); return; end
    n = numel(v);
    if delay >= n; v = repmat(v(end), n, 1); return; end
    v = [v(1+delay:end); repmat(v(end), delay, 1)];
end
