function T = replicate_amp(rawRoot, outCsv, wfMat, cutoff, subjectsIn, daysIn)
% REPLICATE_AMP  既報の眼球運動振幅 (amp) を生データから再現するクリーン版パイプライン。
%
%   T = REPLICATE_AMP() は、リポジトリ同梱の生データ (data/raw) を処理し、
%   公開 config/data_EYE.csv と同じ「回転(ランドルト環1提示)ごと1行」の
%   指標テーブルを返す。列: name, days, trial, direction, c_speed, eye_speed,
%   amp, glass。あわせて data/processed/eye_metrics_replicated.csv に書き出す。
%
%   T = REPLICATE_AMP(rawRoot, outCsv) で入力/出力パスを指定できる。
%
%   ── 位置づけ ──────────────────────────────────────────────────────────
%   これは学生作成の Test_Vertical.m / Test_Horizontal.m (各 ~900 行の
%   モノリシックなスクリプト) を、数値挙動を一切変えずに関数分割・整理した
%   ものである。検証済み: 本関数の amp 出力は data_EYE.csv の全 4848 行と
%   厳密一致する (Vertical 2961 + Horizontal 1887)。
%
%   ── パイプライン (1 試行あたり) ───────────────────────────────────────
%     1. loadTrial        : 較正csv・眼球csv・信号txt を読む
%     2. calibrateAffine  : 5点注視較正 → アフィン変換 tform、提示距離 Puc
%     3. parseSignals     : LabChart 信号 (光センサ/回答/カメラ) を分解
%     4. detectTiming     : カメラ開始・計測開始 rTl_s・回答 Tans・光センサ列
%     5. estimateTargets  : 光センサからランドルト環の提示窓・標的速度を推定
%     6. buildKinematics  : 眼球画素 → アフィン → 25Hz LPF → 微分 → 速度
%     7. extractPerRotation: 提示窓ごとに amp(位置p-p)・c_speed・eye_speed
%
%   ── 方向 (V/H) の違いはたった3点 ─────────────────────────────────────
%     (a) fixedPoints           : 較正の目標角度配置 (水平/垂直で軸を入替)
%     (b) 較正の上下端スロット順  : V=(top,bottom)  H=(bottom,top)
%     (c) 被験者別センサ閾値表    : sensorThresholds() 参照
%   それ以外 (同期検出・フィルタ・標的推定・抽出) は完全共通。
%
%   ── 注意 ──────────────────────────────────────────────────────────────
%   * MATLAB は Signal Processing Toolbox が必要 (butter/filtfilt)。
%   * 元コードは `1:size(x)` (旧MATLABの黙用) に依存していた箇所があり、
%     ここでは挙動を保ったまま `1:size(x,1)` に統一している。
%   * eye_speed 列は「眼が標的に最接近する1サンプルの速度差分」という特殊量で
%     数値的に不安定 (HANDOFF 5.2)。再解析では使わない。amp のみ信頼する。

    % --------------------------------------------------------------------
    % 既定パス (このファイルは <repo>/src/replicate_amp.m にある想定)
    % --------------------------------------------------------------------
    thisDir  = fileparts(mfilename('fullpath'));
    repoRoot = fileparts(thisDir);
    if nargin < 1 || isempty(rawRoot)
        rawRoot = fullfile(repoRoot, 'data', 'raw');
    end
    if nargin < 2 || isempty(outCsv)
        outCsv = fullfile(repoRoot, 'data', 'processed', 'eye_metrics_replicated.csv');
    end
    if nargin < 3; wfMat = ''; end   % 指定時: 回転ごとの amp軸 位置/速度を .mat に保存(感度分析用)
    if nargin < 4 || isempty(cutoff); cutoff = 25; end   % 位置LPFカットオフ[Hz]。既定25=既報再現。
    % subjectsIn / daysIn: 省略時は既報の16名・day0-3。除外4名の検証等で任意指定可。
                                                          % サッケード速度解析用に高帯域(例60)で再ダンプ可。
    dumpWf = ~isempty(wfMat);
    allWf = {};

    % --------------------------------------------------------------------
    % 解析対象 16 名 (Test_*.m の names 配列 先頭16。ループ順を踏襲)
    % --------------------------------------------------------------------
    subjects = ["Subject L","Subject O","Subject B","Subject J","Subject I","Subject N","Subject E","Subject K", ...
                "Subject H","Subject A","Subject M","Subject F","Subject D","Subject G", ...
                "Subject P","Subject C"];
    if nargin >= 5 && ~isempty(subjectsIn); subjects = string(subjectsIn); end

    % 方向ごとの設定 (上記(a)(b))。amp は常に aaData(:,3) の p-p。
    dirs = struct( ...
        'tag',        {"ver",                             "hor"}, ...
        'folder',     {"Vertical",                        "Horizontal"}, ...
        'label',      {"V",                               "H"}, ...
        'fixedPoints',{[0 -45.1; 14.3 0; -14.3 0; 0 45.1; 0 0], ...
                       [-45.1 0; 0 -14.3; 0 14.3; 45.1 0; 0 0]}, ...
        'topBottom',  {"topbottom",                       "bottomtop"});

    NTRIAL = 5;   % 1日あたり試行数
    DAYS   = 0:3; % pre, day1-3
    if nargin >= 6 && ~isempty(daysIn); DAYS = daysIn; end

    % --------------------------------------------------------------------
    % 全 (方向 × 被験者 × 日 × 試行) を処理して行を集める
    % --------------------------------------------------------------------
    allRows = cell(0,1);
    for d = 1:numel(dirs)
        dcfg = dirs(d);
        for s = 1:numel(subjects)
            name = subjects(s);
            for day = DAYS
                for t = 1:NTRIAL
                    [rows, wf] = processTrial(rawRoot, dcfg, name, day, t, cutoff);
                    if ~isempty(rows)
                        allRows{end+1,1} = rows; %#ok<AGROW>
                        if dumpWf; allWf{end+1,1} = wf; end %#ok<AGROW>
                    end
                end
            end
        end
        fprintf('[%s] done (%d subjects)\n', dcfg.label, numel(subjects));
    end
    M = vertcat(allRows{:});   % Nx10: c_speed,eye_speed,name,days,trial,dir,amp,amp_sacc,amp_pursuit,n_sacc

    % --------------------------------------------------------------------
    % テーブル化 (+ glass を config/subject_group.csv から結合)
    % --------------------------------------------------------------------
    T = table( ...
        M(:,3), str2double(M(:,4)), str2double(M(:,5)), M(:,6), ...
        str2double(M(:,1)), str2double(M(:,2)), str2double(M(:,7)), ...
        str2double(M(:,8)), str2double(M(:,9)), str2double(M(:,10)), ...
        'VariableNames', {'name','days','trial','direction','c_speed','eye_speed','amp', ...
                          'amp_sacc','amp_pursuit','n_sacc'});
    T.glass = joinGlass(T.name, fullfile(repoRoot,'config','subject_group.csv'));

    if ~isempty(outCsv)
        outDir = fileparts(outCsv);
        if ~isempty(outDir) && ~isfolder(outDir); mkdir(outDir); end
        writetable(T, outCsv);
        fprintf('wrote %d rows -> %s\n', height(T), outCsv);
    end

    if dumpWf
        WF = vertcat(allWf{:});   % 構造体配列: key(name|days|trial|dir), pos, vel (amp軸)
        save(wfMat, 'WF', '-v7.3');
        fprintf('wrote %d rotation waveforms -> %s\n', numel(WF), wfMat);
    end
end


% ========================================================================
%  1 試行を処理して [c_speed eye_speed name days trial dir amp] 行群を返す
% ========================================================================
function [rows, wf] = processTrial(rawRoot, dcfg, name, day, t, cutoff)
    rows = strings(0,7); wf = struct('key',{},'pos',{},'vel',{},'tgt',{},'tt',{});

    % ---- 1. 読み込み -----------------------------------------------------
    [cali, eye, sig] = loadTrial(rawRoot, dcfg, name, day, t);

    % ---- 2. 較正 → アフィン変換 -----------------------------------------
    [tform, Puc] = calibrateAffine(cali, dcfg);

    % ---- 3. 信号の分解 (センサ入替は Subject H/Subject A の day0 のみ) -----------
    swap = (name=="Subject H" && day==0) || (name=="Subject A" && day==0);
    sg   = parseSignals(sig, swap);

    % ---- 4. 同期タイミング検出 ------------------------------------------
    thr = sensorThresholds(dcfg.tag, name, day, t);   % [th1 th2]
    tm  = detectTiming(sg, thr);
    if isnan(tm.rTl_s) || isnan(tm.Tans)
        return;   % 検出不能な試行はスキップ (通常の16名では発生しない)
    end

    % ---- 5. ランドルト環の提示窓と標的速度 ------------------------------
    %   眼球画素を [rTl_s, Tans] に切り出し、アフィン変換して LPF する。
    eyeXY = table2array(eye(:, 1:3));
    eyeXY(:,1) = eyeXY(:,1) * 0.002;        % フレーム番号 → 秒 (500 fps)
    tgt = estimateTargets(sg, tm, eyeXY, tform, Puc, dcfg.tag, name, day, cutoff);
    if isempty(tgt.pLSData)
        return;
    end

    % ---- 6. 運動学 (位置・速度) の時系列 --------------------------------
    aaData = tgt.aaData;   % [t, X(deg), Y(deg), speed(deg/s)]  ※col3 が amp 用

    % ---- 7. 提示窓ごとに amp / c_speed / eye_speed を算出 ---------------
    [rows, wf] = extractPerRotation(aaData, tgt, name, day, t, dcfg.label);
end


% ========================================================================
%  ヘルパ群
% ========================================================================

function [cali, eye, sig] = loadTrial(rawRoot, dcfg, name, day, t)
% 較正csv・眼球csv・信号txt を読む。
%   例: data/raw/Vertical/Data/Subject O/day0/ver0-Subject O-cali.csv
    base = fullfile(char(rawRoot), char(dcfg.folder), 'Data', char(name), ['day' num2str(day)]);
    pfx  = [char(dcfg.tag) num2str(day) '-' char(name)];
    cali = readtable(fullfile(base, [pfx '-cali.csv']));
    eye  = readtable(fullfile(base, [pfx '-' num2str(t) '.csv']));
    sig  = readmatrix(fullfile(base, [pfx '-' num2str(t) '.txt']));
end


function [tform, Puc] = calibrateAffine(cali, dcfg)
% 5点注視較正からアフィン変換を作る。
%   較正csv の固定サンプル窓で「上端/左/中心/右/下端」を注視しており、
%   その平均瞳孔座標 (movingPoints) を画面角度 (fixedPoints) へ写像する。
%   likelihood 低下等で x<10 または y<10 の点は外れ値として除外。
    top    = meanFixation(cali, 2000, 3000);
    left   = meanFixation(cali, 7500, 8500);
    center = meanFixation(cali, 13500,14500);
    right  = meanFixation(cali, 18500,19500);
    bottom = meanFixation(cali, 23500,24500);

    % 上下端スロットの順序だけ方向で入れ替わる (それ以外は共通)
    if dcfg.topBottom == "topbottom"   % Vertical
        slotMin = top;  slotMax = bottom;
    else                               % Horizontal
        slotMin = bottom; slotMax = top;
    end
    movingPoints = [slotMin; left; right; slotMax; center];

    tform = fitgeotrans(movingPoints, dcfg.fixedPoints, 'affine');

    % 提示距離 Puc = 上下端注視点を変換した2点間の距離
    [xMin, yMin] = transformPointsForward(tform, slotMin(1), slotMin(2));
    [xMax, yMax] = transformPointsForward(tform, slotMax(1), slotMax(2));
    Puc = sqrt((xMax-xMin)^2 + (yMax-yMin)^2);
end


function p = meanFixation(cali, r0, r1)
% 較正窓 [r0,r1] の先頭1000サンプルで、x<10||y<10 を除いた平均 [x y]。
    x = table2array(cali(r0:r1, 2));
    y = table2array(cali(r0:r1, 3));
    x = x(1:1000); y = y(1:1000);
    bad = (x < 10) | (y < 10);
    x(bad) = NaN; y(bad) = NaN;
    p = [mean(x,'omitnan'), mean(y,'omitnan')];
end


function sg = parseSignals(sig, swap)
% LabChart 生信号を分解し、各チャネルの差分(立ち上がり検出用)を作る。
%   通常 Sl1=In6(下側光センサ), Sl2=In7(上側)。Subject H/Subject A day0 のみ入替。
    if swap
        Sl1 = sig(:,7); Sl2 = sig(:,6);
    else
        Sl1 = sig(:,6); Sl2 = sig(:,7);
    end
    time = sig(2:end,1);
    sg.SSl1  = [time, diff(Sl1)];       % 光センサ1 [時刻, 変化量]
    sg.SSl2  = [time, diff(Sl2)];       % 光センサ2
    sg.SSans = [time, diff(sig(:,8))];  % 回答スイッチ
    sg.SScam = [time, diff(sig(:,9))];  % カメラ同期
    sg.n     = size(sig,1);             % 元サンプル数 (ループ上限 n-1)
end


function tm = detectTiming(sg, thr)
% カメラ開始 Tcam_s を基準に、計測開始 rTl_s・回答 Tans・光センサ立ち上がり
% 時刻列 lsData1/lsData2 を1パスで検出する。
%   thr = [th1 th2] は被験者別の光センサ検出閾値 (sensorThresholds)。
%   ※ start 検出の `SSl?(ii,1)>th` は元コードのまま (時刻との比較で実質
%      「最初の立ち上がりを採用」に相当)。数値再現のため温存。
    th1 = thr(1); th2 = thr(2);
    count = 0; count0 = 0; count1 = 0; count2 = 0;
    tm.Tcam_s = NaN; tm.rTl_s = NaN; tm.Tans = NaN;
    lsData1 = []; lsData2 = [];

    for ii = 1:sg.n-1
        % カメラ立ち上がり (1回目=開始 Tcam_s, 2回目=終了)
        if sg.SScam(ii,2) > 1
            count0 = count0 + 1;
            if count0 == 1
                tm.Tcam_s = sg.SScam(ii,1);
            elseif count0 == 2
                count0 = 3;
            end
        end

        % 計測開始 rTl_s (カメラ開始後の最初の光センサ立ち上がり)
        if count0 > 0
            if sg.SSl1(ii,2) > th1 || sg.SSl2(ii,2) > th2
                count = count + 1;
                if sg.SSl1(ii,1) > th1 && count == 1
                    tm.rTl_s = sg.SSl1(ii,1) - tm.Tcam_s; count = count + 1;
                elseif sg.SSl2(ii,1) > th2 && count == 1
                    tm.rTl_s = sg.SSl2(ii,1) - tm.Tcam_s; count = count + 1;
                end
            end
        end

        % 回答スイッチ (立ち下がり)
        if sg.SSans(ii,2) < -0.05
            tm.Tans = sg.SSans(ii,1) - tm.Tcam_s;
        end

        % 光センサ立ち上がり時刻を蓄積 (標的の入退場タイミング)
        if count0 > 0
            if sg.SSl1(ii,2) > th1
                count1 = count1 + 1; lsData1(count1,1) = sg.SSl1(ii,1) - tm.Tcam_s; %#ok<AGROW>
            elseif sg.SSl2(ii,2) > th2
                count2 = count2 + 1; lsData2(count2,1) = sg.SSl2(ii,1) - tm.Tcam_s; %#ok<AGROW>
            end
        end
    end
    tm.LSData1 = lsData1;
    tm.LSData2 = lsData2;
end


function tgt = estimateTargets(sg, tm, eyeXY, tform, Puc, dirTag, name, day, cutoff)
% 光センサ立ち上がり列からランドルト環の提示窓 [pLSData1,pLSData2] と
% 標的速度 pLSData(:,3) を推定し、あわせて運動学時系列 aaData を作る。
%
%   このブロックは元コードで最も分岐が多い部分 (左右センサの取り違え補正、
%   提示回数の左右ズレ補正など)。アルゴリズムは変えず、挙動を保持している。
%   難読なのは元がそうだから: 触ると amp 再現が崩れるため温存する。
    tgt.pLSData = [];
    LSData1 = tm.LSData1; LSData2 = tm.LSData2;
    if isempty(LSData1) || isempty(LSData2); return; end
    Tans = tm.Tans;

    % 立ち上がり群の区切り (>1s のギャップで別提示とみなす)
    p1 = find(diff(LSData1(:,1)) > 1) + 1;
    p2 = find(diff(LSData2(:,1)) > 1) + 1;

    pLSData1 = []; pLSData2 = [];
    % Subject O/Subject I は光センサ1と2が逆に出るため役割を入れ替える (day条件は方向依存)
    swapLandolt = (name=="Subject I" && day>=1) || ...
                  (name=="Subject O" && day>=1 && (dirTag=="hor" || day<3));
    if swapLandolt
        if (LSData1(end,1)-LSData1(1,1) < 1) || (LSData2(end,1)-LSData2(1,1) < 1)
            pLSData2(1,1) = LSData1(1,1);
            pLSData1(1,1) = LSData2(1,1);
        else
            for k = 1:size(p1,1)+1
                if k == 1; pLSData2(k,1) = LSData1(1,1);
                elseif LSData2(p2(k-1,1),1) < Tans; pLSData2(k,1) = LSData1(p1(k-1,1),1); end
            end
            for k = 1:size(p2,1)+1
                if k == 1; pLSData1(k,1) = LSData2(1,1);
                elseif LSData1(p1(k-1,1),1) < Tans; pLSData1(k,1) = LSData2(p2(k-1,1),1); end
            end
        end
    else
        if (LSData1(end,1)-LSData1(1,1) < 1) || (LSData2(end,1)-LSData2(1,1) < 1)
            pLSData1(1,1) = LSData1(1,1);
            pLSData2(1,1) = LSData2(1,1);
        else
            for k = 1:size(p1,1)+1
                if k == 1; pLSData1(k,1) = LSData1(1,1);
                elseif LSData1(p1(k-1,1),1) < Tans; pLSData1(k,1) = LSData1(p1(k-1,1),1); end
            end
            for k = 1:size(p2,1)+1
                if k == 1; pLSData2(k,1) = LSData2(1,1);
                elseif LSData2(p2(k-1,1),1) < Tans; pLSData2(k,1) = LSData2(p2(k-1,1),1); end
            end
        end
    end
    pLSData1(pLSData1==0) = [];
    pLSData2(pLSData2==0) = [];

    % ---- 眼球: 非計測時間を除去 → アフィン → 25Hz LPF --------------------
    rr = size(eyeXY,1);
    XX = []; YY = []; TT = [];
    for q = 1:rr
        if eyeXY(q,1) > tm.rTl_s && eyeXY(q,1) < Tans
            TT(q,1) = eyeXY(q,1); XX(q,1) = eyeXY(q,2); YY(q,1) = eyeXY(q,3); %#ok<AGROW>
        end
    end
    XX(XX==0) = []; YY(YY==0) = []; TT(TT==0) = [];   % 元コードのゼロ除去を踏襲
    [X, Y] = transformPointsForward(tform, XX, YY);
    low = LOW_butterworth([TT, X, Y], 500, cutoff, 4); % [t, X(deg), Y(deg)]  cutoff[Hz]

    % ---- ランドルト環位置の直線当てはめ係数 (Land_a: 傾き, Land_b: 切片) --
    ansIdx1 = pLSData1(:,1) <= Tans; pLSData1 = pLSData1(ansIdx1,:);
    ansIdx2 = pLSData2(:,1) <= Tans; pLSData2 = pLSData2(ansIdx2,:);
    if     size(pLSData1,1) - size(pLSData2,1) < 0
        pLSData1(size(pLSData1,1)+1,1) = Tans;
    elseif size(pLSData1,1) - size(pLSData2,1) > 0
        pLSData2(size(pLSData2,1)+1,1) = Tans;
    end

    D_Land = Puc;
    Land_a = []; Land_b = [];
    for lnd = 1:size(pLSData1,1)
        Land_a(lnd,1) = -D_Land / (pLSData2(lnd,1) - pLSData1(lnd,1)); %#ok<AGROW>
        pLSData1(lnd,1) = pLSData1(lnd,1) + 5.35/Land_a(lnd,1);        % 提示遅れ補正
        pLSData2(lnd,1) = pLSData2(lnd,1) + 5.35/Land_a(lnd,1);
        Land_b(lnd,1) = -Land_a(lnd,1)*pLSData1(lnd,1) + D_Land/2;     %#ok<AGROW>
    end

    % ---- 速度: 微分フィルタ → aaData、前8サンプル除去と4サンプルの時間ずれ補正
    %   amp軸 = 標的が動く major軸。V=col3(Y), H=col2(X)。
    %   ※既報 Table 2 は H で col2 を使用 (Analysis_first版)。公開 config/data_EYE.csv
    %     の H amp は col3(minor軸=誤り)。ここでは正しい major軸を使う。
    %   col5 = amp軸の符号付き速度。サッケード分解に使う（追加列）。
    xd = diff_filter(500, low(:,2));
    yd = diff_filter(500, low(:,3));
    if dirTag == "hor"; vAmp = xd; else; vAmp = yd; end
    aaData = [low(:,1), low(:,2), low(:,3), sqrt(xd.^2 + yd.^2), vAmp];
    aaData(1:8,:) = [];
    m = size(aaData,1);
    for pp = 1:m-4
        aaData(pp,:) = aaData(pp+4,:);   % 4サンプル前方シフト
    end

    % ---- 提示回数の左右ズレ補正 (round 2) と 標的速度・外れ値除去 --------
    if size(pLSData1,1) ~= size(pLSData2,1)
        if     size(pLSData1,1) > size(pLSData2,1) && size(pLSData2,1) ~= 1
            for pls = 1:(size(pLSData1,1)-size(pLSData2,1)); pLSData1(end-pls-1,:) = []; end
        elseif size(pLSData1,1) < size(pLSData2,1) && size(pLSData1,1) ~= 1
            for pls = 1:(size(pLSData2,1)-size(pLSData1,1)); pLSData2(end-pls-1,:) = []; end
        end
    end

    pLSData = [];
    for nrot = 1:size(pLSData1,1)
        pLSData(nrot,1) = pLSData1(nrot,1);                                    %#ok<AGROW>
        pLSData(nrot,2) = pLSData2(nrot,1);                                    %#ok<AGROW>
        pLSData(nrot,3) = D_Land / (pLSData1(nrot,1) - pLSData2(nrot,1));      %#ok<AGROW>
    end
    % 直近との標的速度差が 25 deg/s 超 → 異常として末尾を除去
    if size(pLSData,1) > 1 && abs(pLSData(end,3)-pLSData(end-1,3)) > 25
        pLSData(end,1) = NaN; pLSData1(end,1) = NaN; pLSData2(end,1) = NaN;
    end
    pLSData = rmmissing(pLSData);

    tgt.pLSData  = pLSData;
    tgt.pLSData1 = pLSData1;
    tgt.pLSData2 = pLSData2;
    tgt.Land_a   = Land_a;
    tgt.Land_b   = Land_b;
    tgt.D_Land   = D_Land;
    tgt.aaData   = aaData;
end


function [rows, wf] = extractPerRotation(aaData, tgt, name, day, t, label)
% 各提示窓 (ランドルト環1回転) について要約量を1行ずつ作る:
%   c_speed  = |標的速度|              (その回転の速度段)
%   eye_speed= 眼が標的に最接近した瞬間の速度差分 (特殊量・不安定・未使用)
%   amp      = 窓内の眼球位置(col3)の peak-to-peak  ← 既報 A の per-rotation 素
%   amp_sacc = amp のうちサッケードが担った分 (下記 saccade 分解)
%   amp_pursuit = amp - amp_sacc (追従が担った分, 下限0)
%   n_sacc   = 窓内のサッケード事象数
%
%   サッケード判定: amp軸速度 aaData(:,5)=yd の |v|>THR が [MINLEN,MAXLEN] サンプル
%   連続。MAXLEN 超の連続は「高速追従」とみなし除外 (標的120-600deg/sのため必須)。
    THR = 75; MINLEN = 3; MAXLEN = 50;   % 75deg/s, 6ms〜100ms @500Hz (固定)
    if label == "H"; ampCol = 2; else; ampCol = 3; end   % amp軸: H=col2(X), V=col3(Y)

    pLSData  = tgt.pLSData; pLSData1 = tgt.pLSData1; pLSData2 = tgt.pLSData2;
    Land_a   = tgt.Land_a;  Land_b   = tgt.Land_b; %#ok<NASGU>

    times = 50;                                   % 提示回数の上限 (元コード)
    sizes = min(size(pLSData,1), times);
    rows  = strings(0,10);
    wf    = struct('key',{},'pos',{},'vel',{},'tgt',{},'tt',{});  % 回転ごと: amp軸 位置/速度/標的位置/時刻

    for l = 2:sizes
        % 提示窓 [開始,終了] を光センサ順序に応じて取る
        if pLSData1(1,1) < pLSData2(1,1)
            idx = aaData(:,1) > pLSData1(l,1) & aaData(:,1) < pLSData2(l,1);
        else
            idx = aaData(:,1) > pLSData2(l,1) & aaData(:,1) < pLSData1(l,1);
        end
        PRE = aaData(idx,:);
        if isempty(PRE); continue; end

        eyePos    = PRE(:,ampCol);                          % 眼球位置 (amp軸: V=col3,H=col2)
        velAxis   = PRE(:,5);                               % amp軸速度
        targetPos = Land_a(l,1)*PRE(:,1) + Land_b(l,1);     % 標的(ランドルト)位置
        velDiff   = abs(PRE(:,4) - PRE(1,4));               % 速度差分 (窓頭基準)

        amp = abs(max(eyePos) - min(eyePos));               % ← peak-to-peak

        % --- サッケード分解 ---
        sacc = keepRunsBounded(abs(velAxis) > THR, MINLEN, MAXLEN);
        d = diff([false; sacc; false]); st = find(d==1); en = find(d==-1)-1;
        ampSacc = 0;
        for k = 1:numel(st)
            ampSacc = ampSacc + abs(eyePos(en(k)) - eyePos(st(k)));
        end
        ampPursuit = max(0, amp - ampSacc);
        nSacc = numel(st);

        dist = abs(eyePos - targetPos);                     % 眼-標的距離
        mre  = find(dist == min(dist));                     % 最接近サンプル
        eyeSpeed = velDiff(mre(1));
        cSpeed   = abs(pLSData(l,3));

        rows(end+1,:) = [ string(cSpeed), string(eyeSpeed), name, ...
                          string(day), string(t), label, string(amp), ...
                          string(ampSacc), string(ampPursuit), string(nSacc) ]; %#ok<AGROW>
        wf(end+1,1) = struct('key', sprintf('%s|%d|%d|%s', name, day, t, label), ...
                             'pos', eyePos, 'vel', velAxis, 'tgt', targetPos, 'tt', PRE(:,1)); %#ok<AGROW>
    end
end


function m2 = keepRunsBounded(m, minLen, maxLen)
% 論理 m の True 連続のうち長さ [minLen,maxLen] のものだけ残す
% (minLen未満=ノイズ, maxLen超=高速追従として除外)。
    m = m(:); m2 = false(size(m));
    d = diff([false; m; false]);
    starts = find(d == 1); ends = find(d == -1) - 1;
    for k = 1:numel(starts)
        L = ends(k) - starts(k) + 1;
        if L >= minLen && L <= maxLen
            m2(starts(k):ends(k)) = true;
        end
    end
end


function thr = sensorThresholds(dirTag, name, day, t)
% 被験者・日・試行ごとの光センサ検出閾値 [th1 th2]。
%   元コードで巨大な if-elseif に散らばっていた「手調整のマジックナンバー」を
%   ここ1か所に隔離した。値・条件は原典どおり (Test_Vertical/Horizontal.m)。
%   start検出と光センサ蓄積で同じ閾値を使う。
    if dirTag == "ver"      % ---------------- Vertical ----------------
        if     (name=="Subject L" && day==0) || (name=="Subject J" && day==0)
            thr = [0.1  0.1];
        elseif (name=="Subject L" && day==3) || (name=="Subject J" && day==3 && t~=5) || ...
               (name=="Subject J" && day==2) || (name=="Subject N" && day==1) || (name=="Subject K" && day==3)
            thr = [0.015 0.04];
        elseif (name=="Subject J" && day==3 && t==5) || (name=="Subject A" && day==0 && t==1)
            thr = [0.015 0.02];
        else
            thr = [0.015 0.08];
        end
    else                    % ---------------- Horizontal --------------
        if     (name=="Subject L" && day==0) || (name=="Subject J" && day==0) || name=="Subject O" || name=="Subject I"
            thr = [0.1  0.1];
        elseif (name=="Subject L" && day==3) || (name=="Subject J" && day==3 && t~=5) || (name=="Subject J" && day==2)
            thr = [0.015 0.02];
        elseif (name=="Subject J" && day==3 && t==5) || (name=="Subject L" && day==1) || (name=="Subject L" && day==2)
            thr = [0.015 0.03];
        else
            thr = [0.015 0.02];
        end
    end
end


function glass = joinGlass(names, groupCsv)
% config/subject_group.csv (name,glass,group) から glass ラベルを引く。
    G = readtable(groupCsv, 'TextType','string');
    [tf, loc] = ismember(names, G.name);
    glass = strings(numel(names),1);
    glass(tf) = G.glass(loc(tf));
    glass(~tf) = "NA";
end


% ------------------------------------------------------------------------
%  数値ユーティリティ (元 LOW_but.m / diff_data.m をインライン化)
% ------------------------------------------------------------------------
function y = LOW_butterworth(data, fs, cut, n)
% n 次 Butterworth ローパス + ゼロ位相 (filtfilt)。元 LOW_but.m と同一。
    [b, a] = butter(n, cut/(fs/2), 'low');
    y = filtfilt(b, a, data);
end


function y = diff_filter(wn, x)
% 元 diff_data.m と同一の 8タップ移動差分による微分 (ツールボックス非依存)。
%   y(i) = ( x(i)+x(i-1)+x(i-2) - x(i-6)-x(i-7)-x(i-8) )/18 * wn
    m = numel(x);
    y = zeros(m,1);
    d = zeros(1,9);   % d(1..9) = x(i) .. x(i-8) の遅延線
    for i = 1:m
        d(1:8) = d(2:9);   % シフト
        d(9)   = x(i);
        %   d(9)=x(i) d(8)=x(i-1) d(7)=x(i-2) ... d(1)=x(i-8)
        y(i) = (d(9)+d(8)+d(7) - d(3)-d(2)-d(1))/18 * wn;
    end
end
