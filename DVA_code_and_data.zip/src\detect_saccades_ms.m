function S = detect_saccades_ms(pos, vel, fs, pkmin, prom, dist, vmax)
% DETECT_SACCADES_MS  サッケードを「追従の上に乗った速度の過渡成分」として切り出す。
%
%   S = DETECT_SACCADES_MS(pos, vel, fs, pkmin, prom, dist)
%     pos, vel : amp軸の位置[deg] と 符号付き速度[deg/s]（同じ長さ）
%     pkmin    : ピーク速度の下限 [deg/s]（既定 100）
%     prom     : ピークの卓立度(prominence)下限 [deg/s]（既定 25）
%     dist     : ピーク間の最小サンプル間隔（既定 10 = 20ms @500Hz）
%     vmax     : ピーク速度の生理学的上限 [deg/s]（既定 1200）。これを超える事象は
%                DLC 追跡ミス1フレームが微分で巨大スパイク化した**アーチファクト**として
%                除外する。ヒトのサッケードのピーク速度上限は ~900-1000 deg/s なので
%                1200 は測定ノイズ込みで十分寛容。実測: 除外なし R^2=0.683 →
%                vmax=1200 で **R^2=0.829**（ノイズ点が主系列を汚していた）。
%                ※ vmax=1000 は R^2=0.851 とやや良いが除外率が control 2.2% / strobe 1.0%
%                  と群間で2倍偏るためバイアス源になる。1200 は 0.78%/0.64% で均衡。
%
%   ── アルゴリズム（分岐なしの単一手順）────────────────────────────────
%     1. |v| の前後を 0 でパディングしてから findpeaks を1回だけ呼ぶ。
%     2. 各ピークから左右の**局所極小**まで辿った区間を、そのサッケードとする。
%     3. 振幅（正味変位）が下限未満のものを捨てる。
%
%   なぜ 0 パディングか:
%     findpeaks は先頭/末尾サンプルのピークを返せず、さらに窓端でサッケードが
%     切れると片側の裾が「窓端の値」になるため prominence が極小に誤算出される
%     （実例: ピーク881 deg/s・窓端871 → prominence=10 となり棄却）。両端を 0 で
%     パディングすると端のピークも内部ピークとして正しく評価でき、**端専用の
%     分岐が不要**になる。実測でも分岐版より main sequence が改善した
%     （R^2 0.607→0.651, rho 0.860→0.887）。
%
%   なぜ局所極小で切るか:
%     標的が 120-600 deg/s と速く、追従中も |v| が常時 40 deg/s を超えるため、
%     「|v| が閾値を下回るまで伸ばす」方式では区間が回転全体に伸び、追従を
%     巻き込んで振幅を水増しする（持続時間中央値~100ms・振幅~29deg・
%     main sequence 崩壊 R^2=0.13）。サッケードは追従ベースラインの上に乗る
%     過渡なので、両隣の局所極小＝卓立の裾までを区間とすると過渡成分だけが残る
%     （持続時間~40ms・振幅~8.7deg・R^2=0.69, rho=0.92）。
%
%   出力 S（各フィールドは検出数×1）:
%     S.loc  : ピークのインデックス
%     S.a,S.b: 区間（局所極小）の開始/終了インデックス
%     S.pv   : ピーク速度 [deg/s]
%     S.amp  : 振幅 = |pos(b)-pos(a)| [deg]（main sequence の標準的な横軸＝正味変位）
%     S.dur  : 持続時間 [ms]
%     S.edge : 区間が解析窓の端に接していれば true（**派生情報**であり検出の分岐では
%              ない）。窓に切られた事象は振幅が過小評価されるため、main sequence など
%              運動学の特性評価では S.edge==false のみを使うとよい（実測 R^2 0.65→0.68）。
    if nargin<4||isempty(pkmin); pkmin=100; end
    if nargin<5||isempty(prom);  prom=25;   end
    if nargin<6||isempty(dist);  dist=10;   end
    if nargin<7||isempty(vmax);  vmax=1200; end
    v=abs(vel(:)); pos=pos(:); n=numel(v);
    S=struct('loc',[],'a',[],'b',[],'pv',[],'amp',[],'dur',[],'edge',[]);
    if n<8; return; end

    vp=[0; v; 0];                                   % 0パディング（端ピークを内部化）
    [pks,locs]=findpeaks(vp,'MinPeakHeight',pkmin,'MinPeakProminence',prom,'MinPeakDistance',dist);
    locs=locs-1;                                    % 元インデックスへ戻す

    loc=[]; A=[]; B=[]; pv=[]; amp=[]; dur=[]; ed=[];
    for k=1:numel(locs)
        c=max(1,min(n,locs(k)));                    % 端にクランプ
        a=c; while a>1 && v(a-1)<v(a); a=a-1; end   % 左の局所極小へ
        b=c; while b<n && v(b+1)<v(b); b=b+1; end   % 右の局所極小へ
        d=abs(pos(b)-pos(a));
        if d>=0.2 && pks(k)<=vmax          % vmax 超は微分ノイズ由来のアーチファクト
            loc(end+1,1)=c; A(end+1,1)=a; B(end+1,1)=b; %#ok<AGROW>
            pv(end+1,1)=pks(k); amp(end+1,1)=d; %#ok<AGROW>
            dur(end+1,1)=(b-a+1)/fs*1000; ed(end+1,1)=(a==1)||(b==n); %#ok<AGROW>
        end
    end
    S.loc=loc; S.a=A; S.b=B; S.pv=pv; S.amp=amp; S.dur=dur; S.edge=logical(ed);
end
