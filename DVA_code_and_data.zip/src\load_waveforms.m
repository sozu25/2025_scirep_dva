function WF = load_waveforms(wfMat, delay)
% LOAD_WAVEFORMS  回転ごと波形 (.mat) を読み、速度を位置に時刻整合させて返す。
%
%   WF = LOAD_WAVEFORMS()            既定の 100Hz 波形を、遅延補正込みで読む
%   WF = LOAD_WAVEFORMS(wfMat)       .mat を指定
%   WF = LOAD_WAVEFORMS(wfMat, d)    補正量 d サンプルを明示（d=0 で旧挙動）
%
%   速度を使う解析は**必ずこの関数経由で波形を読む**こと。生の load() を直接
%   使うと diff_filter の 8 ms 群遅延が未補正のまま解析に入る（align_velocity 参照）。
    thisDir = fileparts(mfilename('fullpath')); repoRoot = fileparts(thisDir);
    if nargin<1 || isempty(wfMat)
        wfMat = fullfile(repoRoot,'data','processed','rotation_waveforms_c100.mat');
    end
    if nargin<2 || isempty(delay); delay = 4; end
    L = load(wfMat); WF = L.WF;
    for i = 1:numel(WF)
        WF(i).vel = align_velocity(WF(i).vel, delay);
    end
end
