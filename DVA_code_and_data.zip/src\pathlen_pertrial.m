function T = pathlen_pertrial(repoRoot, VT, forceRebuild)
% PATHLEN_PERTRIAL  Per-trial path-length decomposition of the cumulative eye
%   displacement, i.e. Eq. (2) of the manuscript:
%
%       A = A_ns + A_s,
%       A_ns = sum_{|v(t)| <  VT} |v(t)| dt,
%       A_s  = sum_{|v(t)| >= VT} |v(t)| dt.
%
%   Both components are computed WITHIN a presentation (one rotation of the
%   optotype) and then averaged within a trial, exactly as the linear mixed
%   models of Table 4 are fitted. Result is cached to
%   data/processed/pathlen_pertrial.csv.
%
%   ⚠️ This is NOT the same quantity as data/processed/vsplit_pertrial.csv.
%   That file holds the *signed-displacement* split (sum of dpos over the
%   samples above/below VT), which was an earlier formulation. The manuscript
%   defines A as a path length, so every figure and table must use this file.
%   The two differ by roughly 0.3-0.5 deg in the non-saccadic component.
%
%   Columns: name, days, trial, direction, group, glass, A, saccadic,
%            non_saccadic, sacc_frac   (column names mirror vsplit_pertrial.csv
%            except that pursuit_like is renamed non_saccadic).
%
%   Velocity is read through load_waveforms so that the 8 ms group delay of the
%   legacy differentiator is corrected (see src/align_velocity.m).
    thisDir = fileparts(mfilename('fullpath'));
    if nargin < 1 || isempty(repoRoot);     repoRoot = fileparts(thisDir); end
    if nargin < 2 || isempty(VT);           VT = 75; end          % ref. 22 (Palidis et al.)
    if nargin < 3 || isempty(forceRebuild); forceRebuild = false; end
    addpath(thisDir);

    outCsv = fullfile(repoRoot,'data','processed','pathlen_pertrial.csv');
    if ~forceRebuild && isfile(outCsv)
        T = readtable(outCsv,'TextType','string');
        return
    end

    WF  = load_waveforms(fullfile(repoRoot,'data','processed','rotation_waveforms_hbw.mat'), 4);
    key = string({WF.key}');  Pk = split(key,'|');
    nm  = Pk(:,1); dd = Pk(:,2); tr = Pk(:,3); dr = Pk(:,4);

    n = numel(WF); As = nan(n,1); Ans = nan(n,1);
    for i = 1:n
        v  = WF(i).vel(:);  t = WF(i).tt(:);
        dt = diff(t); dt = [dt; median(dt)];      %#ok<AGROW>  last sample keeps the median step
        av = abs(v);  hi = av >= VT;
        As(i)  = sum(av(hi) .* dt(hi));
        Ans(i) = sum(av(~hi) .* dt(~hi));
    end

    % per presentation -> per trial (mean), as in the models
    trialKey = nm + "|" + dd + "|" + dr + "|" + tr;
    [g, gk]  = findgroups(trialKey);  Q = split(gk,'|');

    G = readtable(fullfile(repoRoot,'config','subject_group.csv'),'TextType','string');
    [~, loc] = ismember(Q(:,1), G.name);
    glass    = G.glass(loc);

    T = table;
    T.name      = Q(:,1);
    T.days      = double(Q(:,2));
    T.trial     = double(Q(:,4));
    T.direction = Q(:,3);
    T.group     = repmat("control", height(Q), 1);
    T.group(glass == "T") = "strobe";
    T.glass        = glass;
    T.saccadic     = splitapply(@(x) mean(x,'omitnan'), As,  g);
    T.non_saccadic = splitapply(@(x) mean(x,'omitnan'), Ans, g);
    T.A            = T.saccadic + T.non_saccadic;
    T.sacc_frac    = T.saccadic ./ T.A;
    T = movevars(T,'A','Before','saccadic');

    writetable(T, outCsv);
    fprintf('pathlen_pertrial: %d trials, VT=%g deg/s, saccadic share %.1f%% -> %s\n', ...
            height(T), VT, 100*sum(T.saccadic)/sum(T.A), outCsv);
end
