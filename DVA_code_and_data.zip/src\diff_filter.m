function y = diff_filter(fs, x)
% DIFF_FILTER  8タップ移動差分による数値微分 (元 diff_data.m と同一)。
%
%   y = DIFF_FILTER(fs, x) は等間隔サンプリング (サンプリング周波数 fs) の
%   1次元信号 x を微分して速度を返す。ツールボックス非依存・MATLAB版非依存。
%
%   定義:
%       y(i) = ( x(i)+x(i-1)+x(i-2) - x(i-6)-x(i-7)-x(i-8) ) / 18 * fs
%   先頭側 (i<9) は不足分を 0 埋めした遅延線で計算する (元コードの挙動)。
%
%   再解析ではこの関数を微分の唯一の実装として使う (legacy パイプラインが
%   公開 amp を生んだのと同じ微分)。位置 [deg] を渡せば速度 [deg/s] を得る。
    x = x(:);
    m = numel(x);
    y = zeros(m,1);
    d = zeros(1,9);          % d(9)=x(i), d(8)=x(i-1), ... , d(1)=x(i-8)
    for i = 1:m
        d(1:8) = d(2:9);     % 遅延線をシフト
        d(9)   = x(i);
        y(i) = (d(9)+d(8)+d(7) - d(3)-d(2)-d(1)) / 18 * fs;
    end
end
