function S = threshold_events(pos, vel, fs, VT, vmax, amin)
% THRESHOLD_EVENTS  サッケード性 excursion を「眼球速度が閾値以上の連続区間」として切り出す。
%
%   S = THRESHOLD_EVENTS(pos, vel, fs)
%     pos, vel : amp軸の位置[deg] と 符号付き速度[deg/s]（同じ長さ。速度は 8ms 群遅延補正済み
%                ＝ load_waveforms 経由で読むこと）
%     VT       : 速度閾値 [deg/s]（既定 75 = 原著引用文献22 Palidis 2017 準拠。標的は 120-600
%                deg/s でいずれにせよ追従不能域）。|v| >= VT の連続サンプル列を1事象とする。
%     vmax     : ピーク速度の生理学的上限 [deg/s]（既定 1200）。超える事象は DLC 追跡ミス1
%                フレームが微分でスパイク化したアーチファクトとして除外。
%     amin     : 振幅（正味変位）の下限 [deg]（既定 0.2）。
%
%   ── 設計（検出器フリー・単一閾値）──────────────────────────────────
%   ピーク検出・prominence・局所極小・GMM を一切使わず、閾値 VT だけで事象を定義する。
%   これは振幅分解（stats/make_tableS1_threshold_robustness.m）が使う per-sample 閾値と
%   **同一の基準**であり、検証（main sequence）と定量（分解）が単一の閾値に一本化される。
%   速度閾値法によるサッケード事象定義は原著引用の ref 22 (Palidis et al. 2017) 準拠。
%
%   実測（60Hz, VT=100, 端8サンプル除外）: n=3564, 振幅中央値 2.8deg, 持続中央値 20ms,
%   main sequence 飽和則 R^2=0.829/rho=0.947, 線形則 r=0.93 ＝生理学的に妥当。
%   ※事象は「サッケードの VT 超の中核」であり、VT 未満の立ち上がり/下がりの裾は含まない
%     （振幅・持続は full saccade より小さめに出る）。分解が数える VT 超の変位と同一物になる。
%
%   出力 S（各フィールドは検出数×1）:
%     S.a, S.b : 区間（閾値クロッシング）の開始/終了インデックス
%     S.pv     : ピーク速度 [deg/s]（区間内 |v| の最大）
%     S.amp    : 振幅 = |pos(b)-pos(a)| [deg]（正味変位）
%     S.dur    : 持続時間 [ms]
    if nargin<4 || isempty(VT);   VT   = 75;   end   % 主指標 = 原著引用文献22 (Palidis 2017) 準拠
    if nargin<5 || isempty(vmax); vmax = 1200; end
    if nargin<6 || isempty(amin); amin = 0.2;  end
    v = abs(vel(:)); pos = pos(:); n = numel(v);
    S = struct('a',[],'b',[],'pv',[],'amp',[],'dur',[]);
    if n < 3; return; end

    m = v >= VT;
    de = diff([0; m; 0]);
    starts = find(de==1); ends = find(de==-1) - 1;

    a=[]; b=[]; pv=[]; amp=[]; dur=[];
    for j = 1:numel(starts)
        s0 = starts(j); e0 = ends(j);
        d = abs(pos(e0) - pos(s0)); p = max(v(s0:e0));
        if d >= amin && p <= vmax
            a(end+1,1)=s0; b(end+1,1)=e0; %#ok<AGROW>
            pv(end+1,1)=p; amp(end+1,1)=d; dur(end+1,1)=(e0-s0+1)/fs*1000; %#ok<AGROW>
        end
    end
    S.a=a; S.b=b; S.pv=pv; S.amp=amp; S.dur=dur;
end
