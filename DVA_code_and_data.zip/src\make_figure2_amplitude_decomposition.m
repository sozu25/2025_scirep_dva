function make_figure2_amplitude_decomposition(pertrialCsv)
% MAKE_FIGURE2_AMPLITUDE_DECOMPOSITION  応答図 (Fig. 1-2): 振幅の saccadic / non-saccadic 成分の
%   訓練日ごとの変化を、既報 Figure 5 (EYE_H_V_results.pdf) と同じバイオリン様式で示す。
%
%   出力: figures/figure2_amplitude_decomposition.png（1枚）
%
%   レイアウト (2行×2列):
%     行1 = Saccadic displacement component,  行2 = Non-saccadic displacement component
%     列1 = A) Training without strobe glasses (control group)
%     列2 = B) Training with strobe glasses (strobe group)
%   各パネル: 横軸=訓練セッション(Pre, Session1-3)。セッションごとに1つのバイオリンを
%     左右に分割し、左半分=Vertical (橙), 右半分=Horizontal (青)。既報 Fig.5 と同配色・同様式。
%     **折れ線（中央値の接続線）は描かない**（著者指示）。
%
%   狙い（査読 R1-3）: 列1(control)では saccadic 成分が訓練で増加、列2(strobe)では
%   その増加が抑制される（＝session×glass 交互作用）。
%
%   ⚠️ 入力は **経路長版** data/processed/pathlen_pertrial.csv（src/pathlen_pertrial.m が生成）。
%      本文 式(2) の A = Σ|v|Δt と同一定義で、Table 4 の LMM と同じ数値。
%      旧 data/processed/vsplit_pertrial.csv は**符号付き変位版で別物**なので使わない。
%   ⚠️ 統計注記（day×strobe テキストボックス）と supertitle は削除した。数値は Table 4 にあり、
%      注記が読んでいた tableS1 は旧ダミー符号化の値なので二重管理になっていた。
%   依存: src/lib/Violin（MIT, リポジトリ同梱）。
    thisDir = fileparts(mfilename('fullpath')); repoRoot = fileparts(thisDir);
    addpath(fullfile(thisDir,'lib','Violin')); addpath(thisDir);
    if nargin<1 || isempty(pertrialCsv)
        T = pathlen_pertrial(repoRoot);            % 経路長版（無ければ波形から生成）
    else
        T = readtable(pertrialCsv,'TextType','string');
    end

    colV = [0.9290 0.6940 0.1250];   % Vertical = 橙/金（既報 Fig.5）
    colH = [0     0.4470 0.7410];    % Horizontal = 青
    comps   = {'saccadic','non_saccadic'};
    compLab = {'Saccadic displacement  [deg]', ...
               'Non-saccadic displacement  [deg]'};
    groups  = ["control","strobe"];
    grpTit  = {'A) Training without strobe glasses (control group)', ...
               'B) Training with strobe glasses (strobe group)'};
    dayLab  = {'Pre-training','Session 1','Session 2','Session 3'};

    fig = figure('Visible','on','Position',[40 40 1000 650]);
    % ---- 体裁既定（figure1 に合わせる。フォント/サイズはここ1箇所で調整）----
    FONT='Times New Roman'; FSax=13; FSlab=14; FSlg=12; FStit=13;
    set(fig,'DefaultAxesFontName',FONT,'DefaultAxesFontSize',FSax, ...
            'DefaultTextFontName',FONT,'DefaultLegendFontSize',FSlg);
    tiledlayout(fig,2,2,'TileSpacing','compact','Padding','compact');

    for r = 1:2
        if r==1; ymax = 90; else; ymax = max(T.(comps{r})) * 1.08; end   % saccadic は 90 に上限固定（外れ値でスケールが伸びるのを防ぐ）
        for c = 1:2
            nexttile; hold on;
            Td = T(T.group==groups(c),:);
            for dd = 0:3
                yV = Td.(comps{r})(Td.direction=="V" & Td.days==dd);
                yH = Td.(comps{r})(Td.direction=="H" & Td.days==dd);
                if ~isempty(yV)
                    Violin({yV}, dd+1, 'HalfViolin','left','QuartileStyle','shadow', ...
                        'DataStyle','scatter','ShowMean',false,'ShowMedian',true, ...
                        'BoxWidth',0.45,'MarkerSize',6,'ViolinColor',{colV});
                end
                if ~isempty(yH)
                    Violin({yH}, dd+1, 'HalfViolin','right','QuartileStyle','shadow', ...
                        'DataStyle','scatter','ShowMean',false,'ShowMedian',true, ...
                        'BoxWidth',0.45,'MarkerSize',6,'ViolinColor',{colH});
                end
            end
            hold off; grid on; box on;
            xlim([0.4 4.6]); xticks(1:4); xticklabels(dayLab);
            ylim([0 ymax]); xlabel('Training session','FontSize',FSlab);
            if c==1; ylabel(compLab{r},'FontSize',FSlab); end
            if r==1; title(grpTit{c},'FontSize',FStit,'FontWeight','normal'); end   % 群タイトルは上段のみ
        end
    end

    % 凡例（Vertical 橙 / Horizontal 青）を下部に手描き
    lax = axes(fig,'Position',[0.30 0.005 0.40 0.035],'Visible','off'); hold(lax,'on');
    scatter(lax,0.32,0.5,80,colV,'filled'); text(lax,0.345,0.5,'Vertical','FontName',FONT,'FontSize',FSlg,'VerticalAlignment','middle');
    scatter(lax,0.55,0.5,80,colH,'filled'); text(lax,0.575,0.5,'Horizontal','FontName',FONT,'FontSize',FSlg,'VerticalAlignment','middle');
    xlim(lax,[0 1]); ylim(lax,[0 1]);


    png = fullfile(repoRoot,'figures','figure2_amplitude_decomposition.png');
    exportgraphics(fig,png,'Resolution',150);
    fprintf('saved %s\n',png);

    % PDF: 'ContentType','vector' を明示しないと、Violin の半透明塗り (FaceAlpha) が
    % 引き金になって図全体がラスタライズされ、テキストが編集不可になる（既定 'auto' の挙動）。
    pdf = fullfile(repoRoot,'figures','figure2_amplitude_decomposition.pdf');
    exportgraphics(fig,pdf,'ContentType','vector');
    fprintf('saved %s\n',pdf);
end
