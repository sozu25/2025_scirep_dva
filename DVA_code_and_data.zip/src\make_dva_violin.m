function make_dva_violin()
% DVA split-violin (V=gold left, H=blue right) per group x session.
% Reproduces manuscript Figure 4 panels C/D using the repo Violin class.
%
% 群分けは config/subject_group.csv を単一の情報源とする（ハードコード禁止）。
% 以前この関数には別の割付をハードコードした版があり、Figure 4 のパネル C/D
% だけがパネル B と異なる割付で作られる原因になった。旧版は
% src/legacy/make_dva_violin_strobe_new.m に退避してある。
%
% 有意差マーク: config の割付で R (lme4 + lmerTest + emmeans, Satterthwaite) により
%   DVA ~ D*G*T + (1|name), REML  の条件付き平均を各 group x session で V vs H 比較し、
%   8 比較を Holm 補正した結果。p_holm は
%     control  session 0..3 : 1.80e-04, 9.84e-08, 7.48e-07, 1.68e-03
%     strobe   session 0..3 : 1.80e-04, 4.31e-11, 1.37e-13, 9.84e-08
%   同じモデルで原稿 Table 1 の固定効果 8 項目が完全再現することを確認済み。

thisDir=fileparts(mfilename('fullpath')); repo=fileparts(thisDir);
addpath(genpath(fullfile(repo,'src','lib','Violin')));
D=readtable(fullfile(repo,'data','processed','dva_pertrial.csv'),'TextType','string');
G=readtable(fullfile(repo,'config','subject_group.csv'),'TextType','string');
[tf,loc]=ismember(D.name,G.name);
assert(all(tf),'subject_group.csv に存在しない被験者があります');
D.isS = (G.glass(loc) == "T");

golV=[0.9290 0.6940 0.1250]; bluH=[0 0.4470 0.7410];
stars.control={'***','***','***','**'};   % session 0..3 (Holm8)
stars.strobe ={'***','***','***','***'};

fig=figure('Visible','on','Position',[60 60 1200 360],'Color','w');
FONT='Times New Roman';
set(fig,'DefaultAxesFontName',FONT,'DefaultTextFontName',FONT,'DefaultAxesFontSize',15);
tl=tiledlayout(fig,1,2,'TileSpacing','compact','Padding','compact');
YL=[270 675];
panels={'control','Control group'; 'strobe','Strobe group'};

for pi=1:2
  gname=panels{pi,1}; ttl=panels{pi,2};
  isS = strcmp(gname,'strobe');
  ax=nexttile(pi); hold(ax,'on');
  for k=1:4   % session index -> day k-1, x position k
    day=k-1;
    vV=D.DVA(D.days==day & D.direction=="V" & D.isS==isS);
    vH=D.DVA(D.days==day & D.direction=="H" & D.isS==isS);
    Violin({vV},k,'HalfViolin','left','QuartileStyle','shadow','DataStyle','scatter',...
        'BoxWidth',0.5,'ShowMean',false,'ShowMedian',false,'MarkerSize',9,'ViolinColor',{golV});
    Violin({vH},k,'HalfViolin','right','QuartileStyle','shadow','DataStyle','scatter',...
        'BoxWidth',0.5,'ShowMean',false,'ShowMedian',false,'MarkerSize',9,'ViolinColor',{bluH});
    % significance bracket (V vs H)
    s=stars.(gname){k}; yb=655;
    plot(ax,[k-0.28 k+0.28],[yb yb],'k-','LineWidth',1);
    if strcmp(s,'n.s.'); fs=20; yo=15; else; fs=20; yo=4; end
    text(ax,k,yb+yo,s,'HorizontalAlignment','center','FontName',FONT,'FontSize',fs);
  end
  xlim(ax,[0.4 4.6]); ylim(ax,YL);
  xticks(ax,1:4); xticklabels(ax,{'Pre-training','1','2','3'});
  xlabel(ax,'Training session'); if pi==1; ylabel(ax,'DVA [deg/s]'); end
  yticks(ax,[300,400,500,600]);
  set(gca,'FontSize',15);
  title(ax,ttl,'FontWeight','bold');
  set(ax,'Box','off','TickDir','out','Layer','top');
end
% shared legend (V gold / H blue) + star note
hV=patch(NaN,NaN,golV,'EdgeColor','none'); hH=patch(NaN,NaN,bluH,'EdgeColor','none');
lg=legend([hV hH],{'Vertical DVA','Horizontal DVA'},'Orientation','horizontal','Box','off');
lg.Layout.Tile='north';
annotation(fig,'textbox',[0.006 0.94 0.5 0.05],'String','* p<0.05  ** p<0.01  *** p<0.001  (Holm)',...
    'EdgeColor','none','FontName',FONT,'FontSize',15,'Color',[0.3 0.3 0.3]);

out=fullfile(repo,'figures','figure4_panelCD.pdf');
if ~exist(fileparts(out),'dir'); mkdir(fileparts(out)); end
exportgraphics(fig,out,'ContentType','vector');
fprintf('wrote %s\n',out);
end
