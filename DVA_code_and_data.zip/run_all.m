function run_all()
% RUN_ALL  同梱データから、原稿の図（データ由来のもの）を再生成する。
%
%   使い方: MATLAB でこのファイルのあるフォルダに移動し、`run_all` と打つだけ。
%   このパッケージは自己完結しており、外部データもパス設定も不要。
%
%   必要な環境: MATLAB R2020b 以降 + Statistics and Machine Learning Toolbox
%               (fitlme) + Signal Processing Toolbox (butter/filtfilt/findpeaks)
%   所要時間: 全体で数分。
%
%   生成物:
%     figures/figure4_panelCD.pdf                     (原稿 図4 パネル C/D)
%     figures/figure2_amplitude_decomposition_V.png   (原稿 図6 垂直)
%     figures/figure2_amplitude_decomposition_H.png   (原稿 図6 水平)
%     figures/figure1_saccade_validation_<subject>.png(原稿 図5)
%
%   ※ 原稿の Table 1-3 と MAE 表、および図4 の有意差マークは R で計算している。
%      MATLAB とは別に次を実行すること:
%          Rscript stats/make_manuscript_stats.R
%      (R 4.3.3 / lme4, lmerTest, emmeans。tables/ に 5 つの CSV を出力)
    root = fileparts(mfilename('fullpath'));
    addpath(fullfile(root,'src'), fullfile(root,'stats'), fullfile(root,'src','lib','Violin'));

    fprintf('\n===== 1/3  図4 パネル C/D: DVA のスプリットバイオリン =====\n');
    make_dva_violin();

    fprintf('\n===== 2/3  図6: 変位のサッカード / 非サッカード成分 =====\n');
    make_figure2_amplitude_decomposition();

    fprintf('\n===== 3/3  図5: サッカード検出の妥当性検証 =====\n');
    make_figure1_saccade_validation();

    fprintf('\n完了。figures/ と tables/ を確認してください。\n');
    fprintf(['次: 原稿の Table 1-3 / MAE 表 / 図4 の有意差マークは\n' ...
             '    Rscript stats/make_manuscript_stats.R  で再現できます。\n']);
end
